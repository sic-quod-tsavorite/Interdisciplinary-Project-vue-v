<template>
  <div class="about">
    <h1>About it</h1>
  </div>
</template>
